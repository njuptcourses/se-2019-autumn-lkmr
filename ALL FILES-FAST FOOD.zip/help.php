﻿<HTML>
<HEAD>
<TITLE>About FAST FOOD</TITLE>
<style type="text/css">
	*{font-family: 'Roboto', sans-serif;}
   a:link {color: #000000}
   a:visited {color: #000000}
   a:hover {color: #000000}
   a:active {color: #000000}
#grad {
background: linear-gradient(to pink,black , white);
}
	
</style>

</HEAD>
<BODY background="bg1.jpg">

<?php include("header.php"); ?>
<TABLE width="1200" height="440" style="border-width:4px; border-style:solid;border-color:#000000;border-radius: 25px;" align="justify" id="grad">
<CAPTION><FONT color="black" size="5">ABOUT FAST FOOD</FONT></CAPTION>
<TR><TD>
<FONT size="6" face="Tahoma">

<?php

echo "Fast food is a convenient canteen food ordering service for Nanjing university of posts and telecommunications Xianlin campus canteens.";
echo "<br>";
echo "<h4 style='color: red;'>Why should you use our service?</h4>";
echo "Well, have you ever found yourself dreading the over crowded canteen, long queues or ever misplaced your campus ID? Then we are the perfect solution for you!";

echo "<br>";
?>
<img src="bg2.jpg" alt="Canteen" style="width: 1200px; height: 400px;">

</BODY>
</HTML>