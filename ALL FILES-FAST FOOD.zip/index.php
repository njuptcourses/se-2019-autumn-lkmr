<HTML>
<HEAD>
<TITLE>Welcome to FAST FOOD</TITLE>
<style type="text/css">
@import url(style.css);
   a:link {color: #000000}
   a:visited {color: #000000}
   a:hover {color: #000000}
   a:active {color: #000000}
</style>
</HEAD>
<BODY background="background1.jpg">
<?php include("header.php"); ?>

<FONT size="6" color="black">

<SECTION>
<MAIN>
<BR>
<BR>

<BR><HR width="1000">
<B><P>Our service is available in Xianlin campus only.<BR> Please select a canteen:</P></B></FONT>

<TABLE >
<TR><TD><FONT size="6"  color="black">
<A HREF="order.php" style="text-decoration: none">1)First Canteen</A></FONT></TD></TR>
<TR><TD><FONT size="6"  color="black">
<A HREF="order.php" style="text-decoration: none">2)Second Canteen</A></FONT></TD></TR>
<TR><TD><FONT size="6"  color="black">
<A HREF="order.php" style="text-decoration: none">3)Third Canteen</A></FONT></TD></TR>

</TABLE>
</SECTION>
</MAIN><BR><BR><HR width="1000">
<FOOTER >
<FONT size="2" color="red">
By continuing past this page, you agree to our Terms of Service and Privacy Policy. NJUPT LKMR 2019. All rights reserved.</FONT>
</FOOTER>
</BODY>
</HTML>